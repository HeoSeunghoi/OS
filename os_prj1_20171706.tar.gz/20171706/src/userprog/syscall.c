#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "syscall.h"
#include "userprog/process.h"
#include "devices/input.h"

#ifndef max
#define max(a, b) (((a) > (b)) ? (a) : (b))
#endif

static void syscall_handler(struct intr_frame*);

void
syscall_init(void)
{
	intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame* f UNUSED)
{
	//printf("<syscall num : %d>\n", *(uint32_t *)(f->esp));
	//printf ("system call!\n");
	//hex_dump(current_esp, current_esp, 500, 1);

	switch (*(uint32_t*)(f->esp))
	{
	case SYS_HALT:
		syscall_halt();
		break;
	case SYS_EXIT:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			syscall_exit(*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_EXEC:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_exec((const char*)*(uint32_t*)(f->esp + 4));
		else 
			syscall_exit(-1);
		break;
	case SYS_WAIT:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_wait((tid_t)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_READ:
		if (is_user_vaddr((const void*)(f->esp + 4)) && 
			is_user_vaddr((const void*)(f->esp + 8)) && 
			is_user_vaddr((const void*)(f->esp + 12)))
			f->eax = syscall_read((int)*((uint32_t*)(f->esp + 4)), (void*)*((uint32_t*)(f->esp + 8)), (unsigned)*((uint32_t*)(f->esp + 12)));
		else
			syscall_exit(-1);
		break;
	case SYS_WRITE:
		if (is_user_vaddr((const void*)(f->esp + 4)) && 
			is_user_vaddr((const void*)(f->esp + 8)) && 
			is_user_vaddr((const void*)(f->esp + 12)))
			f->eax = syscall_write((int)*((uint32_t*)(f->esp + 4)), (void*)*((uint32_t*)(f->esp + 8)), (unsigned)*((uint32_t*)(f->esp + 12)));
		else
			syscall_exit(-1);
		break;
	case SYS_FIBO:
		if(is_user_vaddr((uint32_t*)(f->esp + 4)))
			f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_MAX:
		if (is_user_vaddr((int)*(uint32_t*)(f->esp + 4)) && is_user_vaddr((int)*(uint32_t*)(f->esp + 8)) &&
			is_user_vaddr((int)*(uint32_t*)(f->esp + 12)) && is_user_vaddr((int)*(uint32_t*)(f->esp + 16)))
			f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4),
				(int)*(uint32_t*)(f->esp + 8),
				(int)*(uint32_t*)(f->esp + 12),
				(int)*(uint32_t*)(f->esp + 16));
		else
			syscall_exit(-1);
		break;
	}
}

void syscall_halt(void)
{
	shutdown_power_off();
}

void syscall_exit(int status)
{
	struct thread* tmp = thread_current();
	printf("%s: exit(%d)\n", tmp->name, status);
	tmp->exit_flag = status;
	thread_exit();
}

pid_t syscall_exec(const char* file)
{
	return process_execute(file);
}

int syscall_wait(pid_t pid)
{
	return process_wait(pid);
}

int syscall_read(int fd, void* buffer, unsigned size)
{
	int i = 0;
	if (fd != 0) return -1;
	else if (fd == 0)
	{
		if (size == 0)
			return -1;
		while(1)
		{
			if ((((uint8_t*)buffer)[i] == '\0') || i == size)
				break;
			((uint8_t*)buffer)[i] = input_getc();
			i++;
		}
		return i;
	}
}

int syscall_write(int fd, const void* buffer, unsigned size)
{
	if (fd != 1) return -1;
	else if (fd == 1)
	{
		putbuf(buffer, size);
		return size;
	}
}

int fibonacci(int n)
{
	int i;
	int result = 0, x = 1, y = 1;
	if (n == 0)
		return 0;
	else if (n <= 2)
		return 1;
	for (i = 2; i < n; i++) {
		result = x + y;
		x = y;
		y = result;
	}
	return result;
}

int max_of_four_int(int a, int b, int c, int d)
{
	int x, y;
	x = max(a, b);
	y = max(c, d);
	return max(x, y);
}
