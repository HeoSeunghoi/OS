#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "syscall.h"
#include "userprog/process.h"
#include "devices/input.h"
#include "threads/synch.h"
#include "filesys/off_t.h"

#ifndef max
#define max(a, b) (((a) > (b)) ? (a) : (b))
#endif

// open�� file list�� fp�� �Ҵ��� �ִ� ����
// write�� �Ҵ�� fp�� ���� ����
// lock sync�� fp�� �Ҵ��ϴ� �������� fp�� ���ؼ� write�� �Ѿ�� ���� NULL���·� �Ѿ�� ������ fp�� ���� write�� �ȵ�.
// ���� ���� file list�� index�� ���ؼ� ���ÿ� fp�� �Ҵ��� �� ���� ������ syscall open�ȿ����� lock sync�� �ɾ����

// lock file�� close�� read���̿� �ɸ�
// syscall read�ϴ� ���߿� close�� �� �� ����.
// ���� � fp�� ���ؼ� read�ϴ� ���ε� syscall close�� �����ϸ� ������ �߻�
// ���������� �ݰ��ִ� ���߿� read�ϸ� �ȵ�.

// write ���̿� semapo�� file deny write�� ���

struct lock OW_lock;
struct lock CR_lock;
static void syscall_handler(struct intr_frame*);

void
syscall_init(void)
{
	lock_init(&OW_lock);
	lock_init(&CR_lock);
	intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame* f UNUSED)
{
	//printf("<syscall num : %d>\n", *(uint32_t *)(f->esp));
	//printf ("system call!\n");
	//hex_dump(current_esp, current_esp, 500, 1);

	switch (*(uint32_t*)(f->esp))
	{
	case SYS_HALT:
		syscall_halt();
		break;
	case SYS_EXIT:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			syscall_exit(*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_EXEC:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_exec((const char*)*(uint32_t*)(f->esp + 4));
		else 
			syscall_exit(-1);
		break;
	case SYS_WAIT:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_wait((tid_t)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_READ:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)) && 
			is_user_vaddr((const void*)(f->esp + 12)))
			f->eax = syscall_read((int)*((uint32_t*)(f->esp + 4)), (void*)*((uint32_t*)(f->esp + 8)), (unsigned)*((uint32_t*)(f->esp + 12)));
		else
			syscall_exit(-1);
		break;
	case SYS_WRITE:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)) && 
			is_user_vaddr((const void*)(f->esp + 12)))
			f->eax = syscall_write((int)*((uint32_t*)(f->esp + 4)), (void*)*((uint32_t*)(f->esp + 8)), (unsigned)*((uint32_t*)(f->esp + 12)));
		else
			syscall_exit(-1);
		break;
	case SYS_FIBO:
		if(is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_MAX:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)) &&
			is_user_vaddr((const void*)(f->esp + 12)) && is_user_vaddr((const void*)(f->esp + 16)))
			f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4),
				(int)*(uint32_t*)(f->esp + 8),
				(int)*(uint32_t*)(f->esp + 12),
				(int)*(uint32_t*)(f->esp + 16));
		else
			syscall_exit(-1);
		break;
	case SYS_CREATE:
		if (is_user_vaddr((const void*)(f->esp + 4)) &&	is_user_vaddr((const void*)(f->esp + 8)))
			f->eax = syscall_create((const char*)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
		else
			syscall_exit(-1);
		break;
	case SYS_REMOVE:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_remove((const char*)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_OPEN:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_open((const char*)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_CLOSE:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			syscall_close((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_FILESIZE:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_filesize((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_SEEK:
		if (is_user_vaddr((const void*)(f->esp + 4)) &&	is_user_vaddr((const void*)(f->esp + 8)))
			syscall_seek((int)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
		else
			syscall_exit(-1);
		break;
	case SYS_TELL:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_tell((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	}
}

void syscall_halt(void)
{
	shutdown_power_off();
}

void syscall_exit(int status)
{
	struct thread* tmp = thread_current();
	printf("%s: exit(%d)\n", tmp->name, status);
	tmp->exit_flag = status;
	for (int i = 3; i < 128; i++)
		if (tmp->f_list[i] != NULL)
			syscall_close(i);
	thread_exit();
}

pid_t syscall_exec(const char* file)
{
	return process_execute(file);
}

int syscall_wait(pid_t pid)
{
	return process_wait(pid);
}

int syscall_read(int fd, void* buffer, unsigned size)
{
	struct thread* cur = thread_current();
	struct file* f = cur->f_list[fd];
	int i = 0;
	int result = -1;
	if (!is_user_vaddr(buffer))
		syscall_exit(-1);

	if (&CR_lock == NULL)
		syscall_exit(0);

	lock_acquire(&CR_lock);
	if (fd < 0 || fd == 1 || fd == 2) {
		lock_release(&CR_lock);
		return result;
	}
	else if (fd == 0)
	{
		while(1)
		{
			if ((((uint8_t*)buffer)[i] == '\0') || i == size) {
				break;
			}
			((uint8_t*)buffer)[i] = input_getc();
			i++;
		}
		lock_release(&CR_lock);
		return i;
	}
	else { // fd > 2
		if (f == NULL) {
			lock_release(&CR_lock);
			syscall_exit(-1);
		}
		result = file_read(f, buffer, size);
	}
	lock_release(&CR_lock);
	return result;
}

int syscall_write(int fd, const void* buffer, unsigned size)
{
	struct thread* cur = thread_current();
	struct file* f = cur->f_list[fd];
	int result = -1;


	if (&OW_lock == NULL)
		syscall_exit(1);

	lock_acquire(&OW_lock);
	
	if (fd < 1 || fd == 2) {
		lock_release(&OW_lock);
		return result;
	}
	else if (fd == 1)
	{
		putbuf(buffer, size);
		lock_release(&OW_lock);
		return size;
	}
	else {
		if (f == NULL) {
			lock_release(&OW_lock);
			syscall_exit(-1);
		}
		result = file_write(f, buffer, size);
		if (result == -1) {
			lock_release(&OW_lock);
			syscall_exit(-1);
		}
	}
	lock_release(&OW_lock);
	return result;
}

int fibonacci(int n)
{
	int i;
	int result = 0, x = 1, y = 1;
	if (n == 0)
		return 0;
	else if (n <= 2)
		return 1;
	for (i = 2; i < n; i++) {
		result = x + y;
		x = y;
		y = result;
	}
	return result;
}

int max_of_four_int(int a, int b, int c, int d)
{
	int x, y;
	x = max(a, b);
	y = max(c, d);
	return max(x, y);
}

bool syscall_create(const char* file, unsigned initial_size) {
	if (file == NULL)
		syscall_exit(-1);
	return filesys_create(file, initial_size);
}

bool syscall_remove(const char* file) {
	if (file == NULL)
		syscall_exit(-1);
	return filesys_remove(file);
}

int syscall_open(const char* file) {
	struct file* fp;
	struct thread* cur;
	int i;
	if (file == NULL)
		syscall_exit(-1);


	if (&OW_lock == NULL)
		syscall_exit(2);

	lock_acquire(&OW_lock);
	fp = filesys_open(file);
	if (fp == NULL) {
		lock_release(&OW_lock);
		return -1;
	}
	cur = thread_current();
	for (i = 3; i < 128; i++)
		if (cur->f_list[i] == NULL)
			break;

	if(i != 128){
		if (strcmp(cur->name, file) == 0) file_deny_write(fp);
		cur->f_list[i] = fp;
		lock_release(&OW_lock);
		return i;
	}
	lock_release(&OW_lock);
	return -1;
}
//�̰� ������ �� ���� �� �� Ȯ�� ����
void syscall_close(int fd) {
	struct thread* cur;
	struct file* f;


	if (fd < 0 || fd > 127)
		syscall_exit(-1);

	cur = thread_current();
	f = cur->f_list[fd];


	if (f == NULL) {
		syscall_exit(-1);
	}
	file_close(f);
	cur->f_list[fd] = NULL;
}

int syscall_filesize(int fd) {
	struct thread* cur = thread_current();
	struct file* f = cur->f_list[fd];

	if (f == NULL) syscall_exit(-1);
	return file_length(f);
}

void syscall_seek(int fd, unsigned position) { // 
	struct thread* cur = thread_current();
	struct file* f = cur->f_list[fd];

	if (f == NULL) syscall_exit(-1);
	file_seek(f, position);
}

unsigned syscall_tell(int fd) {
	struct thread* cur = thread_current();
	struct file* f = cur->f_list[fd];

	if (f == NULL) syscall_exit(-1);
	return file_tell(f);
}
