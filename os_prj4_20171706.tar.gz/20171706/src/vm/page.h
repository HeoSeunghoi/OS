#include<hash.h>
#include"devices/block.h"
#include"filesys/off_t.h"
#include"threads/synch.h"

struct page {
	void *vaddr;
	struct hash_elem h_elem;
	struct file *file;
	bool mode_bit;

};
