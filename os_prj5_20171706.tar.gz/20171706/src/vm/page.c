#include"page.h"
#include<stdio.h>
#include<string.h>
#include"userprog/pagedir.h"

#define PT_MAX_SIZE (1024*1024)


