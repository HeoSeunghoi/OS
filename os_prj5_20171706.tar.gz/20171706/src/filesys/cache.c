#include <debug.h>
#include <string.h>
#include "filesys/cache.h"
#include "filesys/filesys.h"
#include "threads/thread.h"
#include "threads/synch.h"

#define BUFFER_CACHE_SIZE 64
int check = 0;
bool success = false;

struct buffer_cache_entry_t {
	bool valid;

	block_sector_t disk_sector;
	uint8_t buffer[BLOCK_SECTOR_SIZE];

	bool dirty;
	bool access;
};

static struct buffer_cache_entry_t cache[BUFFER_CACHE_SIZE];
static struct lock buffer_cache_lock;

void
buffer_cache_init(void)
{
	lock_init(&buffer_cache_lock);

	size_t i = 0;
	while (1) {
		if (i >= BUFFER_CACHE_SIZE) break;
		cache[i++].valid = false;
	}
}

static void
buffer_cache_flush(struct buffer_cache_entry_t* entry)
{
	if (entry->dirty) {
		block_write(fs_device, entry->disk_sector, entry->buffer);
		entry->dirty = false;
	}
}

void
buffer_cache_close(void)
{
	lock_acquire(&buffer_cache_lock);

	size_t i;
	for (i = 0; i < BUFFER_CACHE_SIZE; ++i) {
		success = thread_check(check, 0, success);
		if (cache[i].valid == true)
			buffer_cache_flush(&(cache[i]));
	}

	lock_release(&buffer_cache_lock);
}

static struct buffer_cache_entry_t*
buffer_cache_lookup(block_sector_t sector)
{
	size_t i = 0;
	for (i = 0; i < BUFFER_CACHE_SIZE; ++i) {
		if (cache[i].valid == true && cache[i].disk_sector == sector)
			return &(cache[i]);
	}
	return NULL;
}

static struct buffer_cache_entry_t*
buffer_cache_evict(void)
{
	static size_t clock = 0;
	for (clock = 0; cache[clock].access; clock = (clock + 1) % BUFFER_CACHE_SIZE) {
		if (cache[clock].valid == false)
			return &(cache[clock]);
		cache[clock].access = false;
	}
	if (cache[clock].valid == false)
		return &(cache[clock]);

	struct buffer_cache_entry_t* slot = &cache[clock];
	success = thread_check(check, 1, success);
	if (slot->dirty)
		buffer_cache_flush(slot);

	slot->valid = false;
	return slot;
}

void
buffer_cache_read(block_sector_t sector, void* target)
{
	lock_acquire(&buffer_cache_lock);

	struct buffer_cache_entry_t* slot = buffer_cache_lookup(sector);
	success = thread_check(check, 1, success);
	if (slot == NULL) {
		slot = buffer_cache_evict();

		slot->valid = true;
		slot->dirty = false;
		slot->disk_sector = sector;
		block_read(fs_device, sector, slot->buffer);
	}

	slot->access = true;
	memcpy(target, slot->buffer, BLOCK_SECTOR_SIZE);

	lock_release(&buffer_cache_lock);
}

void
buffer_cache_write(block_sector_t sector, const void* source)
{
	lock_acquire(&buffer_cache_lock);

	struct buffer_cache_entry_t* slot = buffer_cache_lookup(sector);
	if (slot == NULL) {
		slot = buffer_cache_evict();

		slot->valid = true;
		slot->dirty = false;
		slot->disk_sector = sector;
		block_read(fs_device, sector, slot->buffer);
	}

	slot->access = true;
	slot->dirty = true;
	memcpy(slot->buffer, source, BLOCK_SECTOR_SIZE);

	lock_release(&buffer_cache_lock);
}
