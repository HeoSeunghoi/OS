#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "syscall.h"
#include "userprog/process.h"
#include "devices/input.h"
#include "threads/synch.h"
#include "filesys/off_t.h"
#include "filesys/inode.h"
#include "filesys/directory.h"
#include "threads/palloc.h"
#include "threads/malloc.h"

#ifndef max
#define max(a, b) (((a) > (b)) ? (a) : (b))
#endif

// open�� file list�� fp�� �Ҵ��� �ִ� ����
// write�� �Ҵ�� fp�� ���� ����
// lock sync�� fp�� �Ҵ��ϴ� �������� fp�� ���ؼ� write�� �Ѿ�� ���� NULL���·� �Ѿ�� ������ fp�� ���� write�� �ȵ�.
// ���� ���� file list�� index�� ���ؼ� ���ÿ� fp�� �Ҵ��� �� ���� ������ syscall open�ȿ����� lock sync�� �ɾ����

// lock file�� close�� read���̿� �ɸ�
// syscall read�ϴ� ���߿� close�� �� �� ����.
// ���� � fp�� ���ؼ� read�ϴ� ���ε� syscall close�� �����ϸ� ������ �߻�
// ���������� �ݰ��ִ� ���߿� read�ϸ� �ȵ�.

// write ���̿� semapo�� file deny write�� ���

struct lock OW_lock;
struct lock CR_lock;
struct lock file_lock;
static void syscall_handler(struct intr_frame*);
enum fd_search_filter { FD_FILE = 1, FD_DIRECTORY = 2 };

void
syscall_init(void)
{
	lock_init(&OW_lock);
	lock_init(&CR_lock);
	lock_init(&file_lock); //syscall close lock
	intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame* f UNUSED)
{
	//printf("<syscall num : %d>\n", *(uint32_t *)(f->esp));
	//printf ("system call!\n");
	//hex_dump(current_esp, current_esp, 500, 1);

	switch (*(uint32_t*)(f->esp))
	{
	case SYS_HALT:
		syscall_halt();
		break;
	case SYS_EXIT:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			syscall_exit(*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_EXEC:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_exec((const char*)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_WAIT:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_wait((tid_t) * (uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_READ:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)) &&
			is_user_vaddr((const void*)(f->esp + 12)))
			f->eax = syscall_read((int)*((uint32_t*)(f->esp + 4)), (void*)*((uint32_t*)(f->esp + 8)), (unsigned)*((uint32_t*)(f->esp + 12)));
		else
			syscall_exit(-1);
		break;
	case SYS_WRITE:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)) &&
			is_user_vaddr((const void*)(f->esp + 12)))
			f->eax = syscall_write((int)*((uint32_t*)(f->esp + 4)), (void*)*((uint32_t*)(f->esp + 8)), (unsigned)*((uint32_t*)(f->esp + 12)));
		else
			syscall_exit(-1);
		break;
	case SYS_FIBO:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_MAX:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)) &&
			is_user_vaddr((const void*)(f->esp + 12)) && is_user_vaddr((const void*)(f->esp + 16)))
			f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4),
				(int)*(uint32_t*)(f->esp + 8),
				(int)*(uint32_t*)(f->esp + 12),
				(int)*(uint32_t*)(f->esp + 16));
		else
			syscall_exit(-1);
		break;
	case SYS_CREATE:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)))
			f->eax = syscall_create((const char*)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
		else
			syscall_exit(-1);
		break;
	case SYS_REMOVE:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_remove((const char*)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_OPEN:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_open((const char*)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_CLOSE:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			syscall_close((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_FILESIZE:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_filesize((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
	case SYS_SEEK:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)))
			syscall_seek((int)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
		else
			syscall_exit(-1);
		break;
	case SYS_TELL:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_tell((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
#ifdef FILESYS
	case SYS_CHDIR:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_chdir((const char*)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;

	case SYS_MKDIR:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_mkdir((const char*)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;

	case SYS_READDIR:
		if (is_user_vaddr((const void*)(f->esp + 4)) && is_user_vaddr((const void*)(f->esp + 8)))
			f->eax = syscall_readdir((int)*(uint32_t*)(f->esp + 4), (char*)*(uint32_t*)(f->esp + 8));
		else
			syscall_exit(-1);
		break;

	case SYS_ISDIR:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_isdir((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;

	case SYS_INUMBER:
		if (is_user_vaddr((const void*)(f->esp + 4)))
			f->eax = syscall_inumber((int)*(uint32_t*)(f->esp + 4));
		else
			syscall_exit(-1);
		break;
#endif
	}
}

static struct file_desc*
find_file_desc(struct thread* t, int fd, enum fd_search_filter flag)
{
	bool success = false;
	if (fd < 3) {
		return NULL;
	}

	struct list_elem* e;
	struct file_desc* desc;
	if (!list_empty(&t->file_descriptors)) {
		success = thread_check(fd, 1, success);
		e = list_begin(&t->file_descriptors);
		while (e != list_end(&t->file_descriptors)) {
			desc = list_entry(e, struct file_desc, elem);
			if (desc->id == fd && ((desc->dir != NULL && (flag & FD_DIRECTORY)) || (desc->dir == NULL && (flag & FD_FILE))))
				return desc;
			e = list_next(e);
		}
	}
	return NULL;
}

void syscall_halt(void)
{
	shutdown_power_off();
}

void syscall_exit(int status)
{
	struct thread* tmp = thread_current();
	printf("%s: exit(%d)\n", tmp->name, status);
	tmp->exit_flag = status;
	thread_exit();
}

pid_t syscall_exec(const char* file)
{
	return process_execute(file);
}

int syscall_wait(pid_t pid)
{
	return process_wait(pid);
}

int syscall_read(int fd, void* buffer, unsigned size)
{
	int i = 0;
	int result = -1;
	bool success = false;
	if (!is_user_vaddr(buffer))
		syscall_exit(-1);

	if (&CR_lock == NULL)
		syscall_exit(0);

	lock_acquire(&CR_lock);
	if (fd < 0 || fd == 1 || fd == 2) {
		lock_release(&CR_lock);
		return -1;
	}
	else if (fd == 0) {
		while (1) {
			if ((((uint8_t*)buffer)[i] == '\0') || i == size)
				break;
			((uint8_t*)buffer)[i] = input_getc();
			i++;
		}
		lock_release(&CR_lock);
		return i;
	}
	else { // fd > 2
		struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE);
		success = thread_check(fd, 1, success);
		if (file_d && file_d->file) {
			result = file_read(file_d->file, buffer, size);
			lock_release(&CR_lock);
			return result;
		}
		else {
			lock_release(&CR_lock);
			return -1;
		}
	}
}

int syscall_write(int fd, const void* buffer, unsigned size)
{
	int result = -1;
	bool success = false;
	if (&OW_lock == NULL)
		syscall_exit(1);

	lock_acquire(&OW_lock);

	if (fd < 1 || fd == 2) {
		lock_release(&OW_lock);
		return -1;
	}
	else if (fd == 1)
	{
		putbuf(buffer, size);
		lock_release(&OW_lock);
		return size;
	}
	else {
		struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE);
		success = thread_check(fd, 1, success);
		if (file_d && file_d->file) {
			result = file_write(file_d->file, buffer, size);
			lock_release(&OW_lock);
			return result;
		}
		else {
			lock_release(&OW_lock);
			return -1;
		}
	}
}

int fibonacci(int n)
{
	int i;
	int result = 0, x = 1, y = 1;
	if (n == 0)
		return 0;
	else if (n <= 2)
		return 1;
	for (i = 2; i < n; i++) {
		result = x + y;
		x = y;
		y = result;
	}
	return result;
}

int max_of_four_int(int a, int b, int c, int d)
{
	int x, y;
	x = max(a, b);
	y = max(c, d);
	return max(x, y);
}

bool syscall_create(const char* file, unsigned initial_size) {
	if (file == NULL)
		syscall_exit(-1);
	return filesys_create(file, initial_size, false);
}

bool syscall_remove(const char* file) {
	if (file == NULL)
		syscall_exit(-1);
	return filesys_remove(file);
}

int syscall_open(const char* file) {
	struct file_desc* fd = palloc_get_page(0);
	int check = 0;
	bool success = false;

	if (file == NULL)
		syscall_exit(-1);
	if (&OW_lock == NULL)
		syscall_exit(2);

	lock_acquire(&OW_lock);
	struct file* fp = filesys_open(file);
	if (!fp) {
		palloc_free_page(fd);
		lock_release(&OW_lock);
		return -1;
	}

	fd->file = fp;

	struct inode* inode = file_get_inode(fd->file);
	if (inode != NULL && inode_is_directory(inode))
		fd->dir = dir_open(inode_reopen(inode));
	else fd->dir = NULL;
	success = thread_check(check, 1, success);
	struct list* fd_list = &thread_current()->file_descriptors;
	if (list_empty(fd_list)) {
		fd->id = 3;
		list_push_back(fd_list, &(fd->elem));
		lock_release(&OW_lock);
		return fd->id;
	}
	else {
		fd->id = (list_entry(list_back(fd_list), struct file_desc, elem)->id) + 1;
		list_push_back(fd_list, &(fd->elem));
		lock_release(&OW_lock);
		return fd->id;
	}
}

void syscall_close(int fd) {
	lock_acquire(&file_lock);
	struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE | FD_DIRECTORY);

	if (file_d && file_d->file) {
		file_close(file_d->file);
		if (file_d->dir) dir_close(file_d->dir);
		list_remove(&(file_d->elem));
		palloc_free_page(file_d);
	}
	lock_release(&file_lock);
}

int syscall_filesize(int fd) {
	struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE);

	if (file_d == NULL) return -1;
	return file_length(file_d->file);
}

void syscall_seek(int fd, unsigned position) {
	struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE);

	if (file_d && file_d->file)
		file_seek(file_d->file, position);
}

unsigned syscall_tell(int fd) {
	struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE);

	if (file_d && file_d->file)
		return file_tell(file_d->file);
	else return -1;
}

#ifdef FILESYS
bool syscall_chdir(const char* filename)
{
	return filesys_chdir(filename);
}

bool syscall_mkdir(const char* filename)
{
	return filesys_create(filename, 0, true);
}

bool syscall_readdir(int fd, char* name)
{
	struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_DIRECTORY);
	int check = 0;
	bool success = false;
	if (file_d == NULL) return false;

	struct inode* inode;
	success = thread_check(check, 1, success);
	inode = file_get_inode(file_d->file);
	if (inode == NULL || !inode_is_directory(inode)) return false;

	return dir_readdir(file_d->dir, name);
}

bool syscall_isdir(int fd)
{
	struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE | FD_DIRECTORY);
	struct inode* inode = file_get_inode(file_d->file);
	return inode_is_directory(inode);
}

int syscall_inumber(int fd)
{
	struct file_desc* file_d = find_file_desc(thread_current(), fd, FD_FILE | FD_DIRECTORY);
	struct inode* inode = file_get_inode(file_d->file);
	return (int)inode_get_inumber(inode);
}

#endif