#include<stdio.h>
#include<syscall.h>
#include<stdlib.h>
int main(int argc, int *argv[])
{
	int fibo = atoi(argv[1]);
	printf("%d ", fibonacci(fibo));

	int a = atoi(argv[2]);
	int b = atoi(argv[3]);
	int c = atoi(argv[4]);
	
	printf("%d\n", max_of_four_int(fibo, a, b, c));
	
	return 0;
}
